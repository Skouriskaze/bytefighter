#ifndef DEFEAT_BITMAP_H
#define DEFEAT_BITMAP_H
extern const unsigned short defeat[38400];
#define DEFEAT_WIDTH 240
#define DEFEAT_HEIGHT 160
#endif