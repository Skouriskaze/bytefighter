#ifndef LIFE_BITMAP_H
#define LIFE_BITMAP_H
extern const unsigned short life[256];
#define LIFE_WIDTH 16
#define LIFE_HEIGHT 16
#endif