#ifndef COMPUTER_BITMAP_H
#define COMPUTER_BITMAP_H
extern const unsigned short computer[64];
#define COMPUTER_WIDTH 8
#define COMPUTER_HEIGHT 8
#endif