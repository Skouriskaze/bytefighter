#ifndef STANDARD_BITMAP_H
#define STANDARD_BITMAP_H
extern const unsigned short standard[3776];
#define STANDARD_WIDTH 472
#define STANDARD_HEIGHT 8
#endif