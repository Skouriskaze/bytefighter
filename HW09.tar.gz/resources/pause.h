#ifndef PAUSE_BITMAP_H
#define PAUSE_BITMAP_H
extern const unsigned short pause[38400];
#define PAUSE_WIDTH 240
#define PAUSE_HEIGHT 160
#endif