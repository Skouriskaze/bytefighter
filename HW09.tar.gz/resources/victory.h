#ifndef VICTORY_BITMAP_H
#define VICTORY_BITMAP_H
extern const unsigned short victory[38400];
#define VICTORY_WIDTH 240
#define VICTORY_HEIGHT 160
#endif