#ifndef DEAD_BITMAP_H
#define DEAD_BITMAP_H
extern const unsigned short dead[256];
#define DEAD_WIDTH 16
#define DEAD_HEIGHT 16
#endif