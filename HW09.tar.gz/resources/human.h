#ifndef HUMAN_BITMAP_H
#define HUMAN_BITMAP_H
extern const unsigned short human[64];
#define HUMAN_WIDTH 8
#define HUMAN_HEIGHT 8
#endif