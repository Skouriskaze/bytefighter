-------------------------------------------------------------------------------------------------
Byte Fighter
Jesse Huang
-------------------------------------------------------------------------------------------------

Introduction
------------
Byte Fighter is a fast-paced shooter game. You play against a computer, and both of you have five
lives. The objective it to kill your opponent before you die.


Controls
--------
        (A) - Shoot bullet
        (B) - Shoot missile
        (L) - Shield
        (R) - Shield
    (Start) - Pause
   (Select) - Restart


Logistics and HUD
-----------------
You are the blue ship on the bottom. To the right, you will see hearts. The top five are your
opponents, and the bottom five are yours. Every time you are hit, you lose a heart. When you hit
zero hearts, you lose.
There are two types of bullets. Regular bullets are white and move at a decent speed, but missiles
are green and move faster than regular bullets. You can have four regular bullets and one missile on
the screen at once.
You have a shield. This is the blue bar next to you. When you use the shield and get hit, you do not
lose a heart. As you use your shield, you lose charges. Charges will replenish slowly when the
shield is off.
